---
name: Bug report
about: Report a UI/API/authentication issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Description

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Actual behavior

## Screenshots

## Device / OS
